<?php

    session_start();

    if(!isset($_SESSION['id_usu'])){
        header("Location: ../../index.php");
        exit();
    }

    include("../../conexion.php");

    // Obtener el nit_cc_ase y el nombre del usuario relacionado desde las tablas asesores y usuarios
    $stmt = $mysqli->prepare("
        SELECT a.nit_cc_ase, u.nombre 
        FROM asesores a
        INNER JOIN usuarios u ON a.id_usu = u.id_usu
        WHERE a.id_usu = ?");
    $stmt->bind_param('i', $_SESSION['id_usu']);
    $stmt->execute();
    $stmt->bind_result($nit_cc_ase, $nombre_usu);
    $stmt->fetch();
    $stmt->close();

    if (!$nombre_usu || !$nit_cc_ase) {
        die("Error: El usuario no está registrado correctamente en las tablas.");
    }

    header("Content-Type: text/html;charset=utf-8");
    date_default_timezone_set("America/Bogota");

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>VISION | SOFT</title>
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <script type="text/javascript" src="../../js/jquery.min.js"></script>
    <script type="text/javascript" src="../../js/popper.min.js"></script>
    <script type="text/javascript" src="../../js/bootstrap.min.js"></script>
    <link href="../../fontawesome/css/all.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/fed2435e21.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/signature_pad@4.1.7/dist/signature_pad.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <style>
        .responsive {
            max-width: 100%;
            height: auto;
        }
        /* Reducir el tamaño de la fuente en los labels y añadir color gris claro */
        label {
            font-size: 10px; /* Ajuste entre 9 y 10px */
            font-weight: bold;
            color: #000000; /* Color gris muy claro */
            transition: color 0.3s ease; /* Transición suave para el cambio de color */
        }
        /* Ajustar tamaño de las cajas de texto y select para que sean iguales */
        input.form-control, select.form-control {
            font-size: 12px; /* Ajuste del tamaño de la fuente dentro de las cajas de texto */
            padding: 0.3rem 0.6rem; /* Ajusta el relleno para hacer las cajas más compactas */
            color: black; /* Texto en negro */
            box-sizing: border-box; /* Asegura que el padding se incluya dentro de la altura */
            height: 32px; /* Fija la altura de input y select para que sean iguales */
        }

        textarea.form-control {
            font-size: 12px; /* Ajuste del tamaño de la fuente dentro de las cajas de texto */
            padding: 0.3rem 0.6rem; /* Ajusta el relleno para hacer las cajas más compactas */
            color: black; /* Texto en negro */
            box-sizing: border-box; /* Asegura que el padding se incluya dentro de la altura */
        }
        /* Aplicar fondo pastel cuando el input o select está en foco */
        input.form-control:focus, select.form-control:focus, textarea.form-control:focus {
            background-color: #f0e68c; /* Fondo color pastel */
            outline: none; /* Eliminar borde azul de enfoque en navegadores */
        }
        /* Resaltar el label cuando el input o select está en foco */
        .form-group:focus-within label {
            color: #c68615; /* Cambia el color del label cuando el input o select está en foco */
        }
    .form-container {
        border: 1px solid #ccc;
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 20px;
        background-color: #f9f9f9;
        }

        fieldset {
            border: 1px solid #ddd;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        legend {
            font-weight: bold;
            font-size: 0.9em;
            color: #4a4a4a;
            padding: 0 10px;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        /* Efecto de enfoque para el fieldset */
        fieldset:focus-within {
            background-color: #e6f7ff; /* Azul muy claro */
            box-shadow: 0 0 10px rgba(0, 123, 255, 0.3); /* Sombreado azul claro */
        }
    </style>
    <script>
        $(document).ready(function () {
            $('.select2').select2(); // Inicializar Select2 en todos los selectores con clase 'select2'
        });
    </script>
    <script>
        function ordenarSelect(id_componente) {
            var selectToSort = jQuery('#' + id_componente);
            var optionActual = selectToSort.val();
            selectToSort.html(selectToSort.children('option').sort(function (a, b) {
                return a.text === b.text ? 0 : a.text < b.text ? -1 : 1;
            })).val(optionActual);
        }

        $(document).ready(function () {
            ordenarSelect('cod_dane_dep');
            ordenarSelect('id_mun');
        });
    </script>
    <script>
        function openMap() {
            var mapContainer = document.getElementById("map");
            mapContainer.style.display = "block"; // Mostrar el mapa

            // Inicializar el mapa
            var map = new google.maps.Map(mapContainer, {
                center: { lat: 4.8142613, lng: -75.6946776 }, // Centro inicial (Bogotá)
                zoom: 13
            });

            var marker = new google.maps.Marker({
                position: map.getCenter(),
                map: map,
                draggable: true // Permitir que el marcador se arrastre
            });

            // Actualizar la ubicación al arrastrar el marcador
            google.maps.event.addListener(marker, 'dragend', function (event) {
                document.getElementById("ubicacion_gps_cap").value = event.latLng.lat() + "," + event.latLng.lng();
            });
        }
    </script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBDYjR0V-srAzEF_73RWUgPxvJFOkV1Lnk&callback=openMap"></script>
</head>
<body>
    
    <div class="container">
        <h1><img src='../../img/logo.png' width="80" height="56" class="responsive"><b><i class="fa-solid fa-building-circle-check"></i> FICHA TECNICA INMUEBLES COMERCIALES</b></h1>
        <p><i><b><font size=3 color=#c68615>*Datos obligatorios</i></b></font></p>

        <form action='addcap1.php' enctype="multipart/form-data" method="POST">

            <div class="form-group">
                <fieldset>
                    <legend>UBICACION - MEDIDAS</legend>
                    <div class="row">
                        <div class="col-12 col-sm-2">
                            <label for="cod_dane_dep">* DEPARTAMENTO:</label>
                            <select id = "cod_dane_dep" class = "form-control" name = "cod_dane_dep" required = "required">
                                <option value = ""></option>
                                <?php
                                    $sql = $mysqli->prepare("SELECT * FROM departamentos");
                                    if($sql->execute()){
                                        $g_result = $sql->get_result();
                                    }
                                    while($row = $g_result->fetch_array()){
                                ?>
                                    <option value = "<?php echo $row['cod_dane_dep']?>"><?php echo $row['nom_dep']?></option>
                                <?php
                                        }
                                    $mysqli->close();   
                                ?>
                            </select>
                        </div>
                        <div class="col-12 col-sm-2">
                            <label for="id_mun">* MUNICIPIOS:</label>
                            <select  id = "id_mun" name = "id_mun"  class = "form-control" disabled = "disabled" required = "required">
                                    <option value = "">* SELECCIONE EL MUNICIPIO:</option>
                                </select>
                        </div>
                        <div class="col-12 col-sm-2">
                        <label for="posición_cap">POSICIÓN:</label>
                            <select class="form-control" name="posición_cap" id="posición_cap" >
                                <option value=""></option>
                                <option value="Vista al sur">Vista al sur</option>
                                <option value="Vista al norte">Vista al norte</option>
                                <option value="Vista al oriente">Vista al oriente</option>
                                <option value="Otra">Otra</option>
                            </select>
                        </div>
                        <div class="col-12 col-sm-2">
                            <label for="ubicacion_gps_cap">UBICACION GPS:</label>
                            <input type='text' name='ubicacion_gps_cap' class='form-control' id="ubicacion_gps_cap" readonly/>
                            <button type="button" class="btn btn-sm btn-outline-info" onclick="openMap()">Seleccionar en el Mapa</button>
                            <!-- Contenedor para el mapa -->
                            <div id="map" style="height: 300px; display: none;"></div>
                        </div>
                        <div class="col-12 col-sm-2">
                            <label for="estrato_cap">* ESTRATO:</label>
                            <select class="form-control" name="estrato_cap" id="estrato_cap" required>
                                <option value=""></option>   
                                <option value=1>1</option>
                                <option value=2>2</option>
                                <option value=3>3</option>
                                <option value=4>4</option>
                                <option value=5>5</option>
                                <option value=6>6</option>
                                <option value=7>7</option>
                                <option value=8>8</option>
                                <option value=9>9</option>
                                <option value=10>10</option>
                            </select>
                        </div>
                        <div class="col-12 col-sm-2">
                            <label for="area_total_cap">* AREA TOTAL:</label>
                            <input type='number' name='area_total_cap' class='form-control' id="area_total_cap" required />
                        </div>
                    </div>
                    <script>
                        //$('#doc_acud').select2();
                        $("#id_mun").select2({
                            tags: true
                        });
                    </script>
                </fieldset>
            </div>

            <div class="form-group">
                <fieldset>
                    <legend>DATOS DE CONTACTO</legend>
                    <div class="row">
                        <div class="col-12 col-sm-5">
                            <label for="nombre_razon_social_cap">* NOMBRE y/o RAZON SOCIAL:</label>
                            <input type='text' name='nombre_razon_social_cap' class='form-control' id="nombre_razon_social_cap" required style="text-transform:uppercase;" />
                        </div>
                        <div class="col-12 col-sm-2">
                            <label for="cel_repre_legal_cap">* CELULAR:</label>
                            <input type='number' value=0 name='cel_repre_legal_cap' id="cel_repre_legal_cap" class='form-control' required />
                        </div>
                        <div class="col-12 col-sm-2">
                            <label for="tel_repre_legal_cap">TELEFONO:</label>
                            <input type='number' value=0 name='tel_repre_legal_cap' id="tel_repre_legal_cap" class='form-control' />
                        </div>
                    </div>
                </fieldset>
            </div>

            <div class="form-group">
                <fieldset>
                    <legend>VALORES</legend>
                    <div class="row">
                        <div class="col-12 col-sm-2">
                            <label for="canon_neto_cap">* CANON NETO $</label>
                            <input type='number' name='canon_neto_cap' class='form-control' id="canon_neto_cap" step='0.1' required/>
                        </div>
                        <div class="col-12 col-sm-2">
                            <label for="porcentaje_iva_cap">* % IVA:</label>
                            <input type='number' name='porcentaje_iva_cap' class='form-control' id="porcentaje_iva_cap" min='1.0' max='100' step='0.1' value=19.0 required/>
                        </div>
                        <div class="col-12 col-sm-2">
                            <label for="valor_iva_cap">* VALOR IVA $</label>
                            <input type='text' name='valor_iva_cap' class='form-control' id="valor_iva_cap" readonly style="font-weight: bold; font-size: 14px;" />
                        </div>
                        <div class="col-12 col-sm-2">
                            <label for="admon_cap">* ADMINISTRACION $</label>
                            <input type='number' name='admon_cap' class='form-control' id="admon_cap" step='0.1' required/>
                        </div>
                        <div class="col-12 col-sm-2">
                            <label for="renta_total_cap">* RENTA TOTAL $</label>
                            <input type='text' name='renta_total_cap' class='form-control' id="renta_total_cap" readonly style="font-weight: bold; font-size: 14px;" />
                        </div>
                    </div>
                </fieldset>
            </div>

            <button type="submit" class="btn btn-outline-warning">
                    <span class="spinner-border spinner-border-sm"></span>
                    INGRESAR REGISTRO
            </button>
            <button type="reset" class="btn btn-outline-dark" role='link' onclick="history.back();" type='reset'><img src='../../img/atras.png' width=27 height=27> REGRESAR
            </button>
        </form>
    </div>
</body>
    <script src = "../../js/jquery-3.1.1.js"></script>
    <script type = "text/javascript">
        $(document).ready(function(){
            $('#cod_dane_dep').on('change', function(){
                    if($('#cod_dane_dep').val() == ""){
                        $('#id_mun').empty();
                        $('<option value = "">Seleccione un municipio</option>').appendTo('#id_mun');
                        $('#id_mun').attr('disabled', 'disabled');
                    }else{
                        $('#id_mun').removeAttr('disabled', 'disabled');
                        $('#id_mun').load('modules_get.php?cod_dane_dep=' + $('#cod_dane_dep').val());
                    }
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            function formatCOP(value) {
                return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP' }).format(value);
            }

            function calcularValores() {
                var canon_neto = parseFloat($('#canon_neto_cap').val()) || 0;
                var porcentaje_iva = parseFloat($('#porcentaje_iva_cap').val()) || 0;
                var admon = parseFloat($('#admon_cap').val()) || 0;

                var valor_iva = canon_neto * (porcentaje_iva / 100);
                var renta_total = canon_neto + valor_iva + admon;

                $('#valor_iva_cap').val(formatCOP(valor_iva));
                $('#renta_total_cap').val(formatCOP(renta_total));
            }

            // Escuchar los cambios en los campos relevantes
            $('#canon_neto_cap, #porcentaje_iva_cap, #admon_cap').on('input', function() {
                calcularValores();
            });
        });
    </script>
</html>
