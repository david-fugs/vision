<?php
session_start();

if (!isset($_SESSION['id_usu'])) {
    header("Location: ../../index.php");
}

$nombre = $_SESSION['nombre'];
$tipo_usu = $_SESSION['tipo_usu'];
header("Content-Type: text/html;charset=utf-8");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>VISION | SOFT</title>
    <link href="../../css/bootstrap.min.css" rel="stylesheet">
    <link href="../../fontawesome/css/all.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/fed2435e21.js" crossorigin="anonymous"></script>
    <script type="text/javascript" src="../../js/jquery.min.js"></script>
    <!-- Using Select2 from a CDN-->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <style>
        .responsive {
            max-width: 100%;
            height: auto;
        }
        .checkbox-group-1, .checkbox-group-2, .checkbox-group-3, .checkbox-group-4 {
            display: none;
            margin-top: 20px;
        }
        .comision-pago {
            font-weight: bold;
            font-size: 20px;
        }
    </style>

    <script>
        $(document).ready(function() {
            // Inicialmente deshabilitar los campos correspondientes
            $('select[name="transferencia_propietario"]').prop('disabled', true);
            $('select[name="factura_electronica1"]').prop('disabled', true).val('N/A');
            $('select[name="factura_electronica2"]').prop('disabled', true).val('N/A');
            $('#comision2').prop('disabled', true).val('');
            $('#acuerdo').prop('disabled', true).val('');

            // Deshabilitar campos de impuestos al inicio
            $('#rte_fte1, #rte_fte2, #rte_ica1, #rte_ica2, #rte_iva1, #rte_fte3, #rte_ica3, #rte_iva2').prop('disabled', true).val('');
            $('#iva_inmo, #rte_fte4').prop('disabled', true).val(''); // Ajuste 1

            // Escuchar cambios en el campo pago_propietario
            $('select[name="pago_propietario"]').change(function() {
                var pagoPropietario = $(this).val();

                if (pagoPropietario === 'TRANSFERENCIA') {
                    $('select[name="transferencia_propietario"]').prop('disabled', false);
                } else {
                    $('select[name="transferencia_propietario"]').prop('disabled', true).val('N/A');
                }
            });

            // Escuchar cambios en el campo factura_electronica0
            $('select[name="factura_electronica0"]').change(function() {
                var facturaElectronica0 = $(this).val();

                if (facturaElectronica0 === 'SI') {
                    $('select[name="factura_electronica1"]').prop('disabled', false)
                        .html('<option value="Factura Electrónica">Factura Electrónica</option>');
                    $('select[name="factura_electronica2"]').prop('disabled', true).val('N/A');
                } else if (facturaElectronica0 === 'NO') {
                    $('select[name="factura_electronica1"]').prop('disabled', false)
                        .html('<option value="Orden de Pago">Orden de Pago</option><option value="NO">NO</option>');
                    $('select[name="factura_electronica1"]').change(function() {
                        var facturaElectronica1 = $(this).val();
                        if (facturaElectronica1 === 'Orden de Pago') {
                            $('select[name="factura_electronica2"]').prop('disabled', true).val('N/A');
                        } else if (facturaElectronica1 === 'NO') {
                            $('select[name="factura_electronica2"]').prop('disabled', true).val('Factura Propietario');
                        }
                    });
                }
            });

            // Mostrar los checkboxes cuando el perfil es 1, 2, 3 o 4
            $('select[name="perfil"]').change(function() {
                var perfil = $(this).val();

                // Deshabilitar y limpiar campos de impuestos
                $('#rte_fte1, #rte_fte2, #rte_ica1, #rte_ica2, #rte_iva1, #rte_fte3, #rte_ica3, #rte_iva2').prop('disabled', true).val('');
                $('#iva_inmo, #rte_fte4').prop('disabled', true).val('');

                if (perfil == 1) {
                    $('.checkbox-group-1').show();
                    $('.checkbox-group-2, .checkbox-group-3, .checkbox-group-4').hide();
                    $('.checkbox-group-1 input[type="checkbox"]').prop('checked', true).val(1);
                    $('.checkbox-group-2 input[type="checkbox"], .checkbox-group-3 input[type="checkbox"], .checkbox-group-4 input[type="checkbox"]').prop('checked', false).val(0);
                } else if (perfil == 2) {
                    $('#rte_fte1, #rte_ica1').prop('disabled', false);
                    $('.checkbox-group-2').show();
                    $('.checkbox-group-1, .checkbox-group-3, .checkbox-group-4').hide();
                    $('.checkbox-group-2 input[type="checkbox"]').prop('checked', true).val(1);
                    $('input[name="cbox8"]').prop('checked', true).val(1);
                    $('input[name="cbox17"]').prop('checked', true).val(1);
                    $('.checkbox-group-1 input[type="checkbox"], .checkbox-group-3 input[type="checkbox"], .checkbox-group-4 input[type="checkbox"]').prop('checked', false).val(0);

                    // Calcular impuestos cuando perfil es 2
                    calcularImpuestos();

                    // Asegurarse de que se realice el cálculo correcto y se habilite el campo rte_ica1
                    $('input[name="cbox8"]').change(function() {
                        if ($(this).is(':checked')) {
                            $('#rte_ica1').prop('disabled', false);
                        } else {
                            $('#rte_ica1').prop('disabled', true).val('');
                            $('#rte_ica2').val('');
                        }
                    });

                    // Asegurarse de que se realice el cálculo correcto para rte_iva1
                    $('input[name="cbox17"]').change(function() {
                        if ($(this).is(':checked')) {
                            calcularImpuestos();
                        } else {
                            $('#rte_iva1').val('');
                        }
                    });

                } else if (perfil == 3) {
                    $('.checkbox-group-3').show();
                    $('.checkbox-group-1, .checkbox-group-2, .checkbox-group-4').hide();
                    $('.checkbox-group-3 input[type="checkbox"]').prop('checked', true).val(1);
                    $('input[name="cbox12"]').prop('checked', false).val(0);
                    $('.checkbox-group-1 input[type="checkbox"], .checkbox-group-2 input[type="checkbox"], .checkbox-group-4 input[type="checkbox"]').prop('checked', false).val(0);
                } else if (perfil == 4) {
                    $('.checkbox-group-4').show();
                    $('.checkbox-group-1, .checkbox-group-2, .checkbox-group-3').hide();
                    $('.checkbox-group-4 input[type="checkbox"]').prop('checked', true).val(1);
                    $('input[name="cbox16"]').prop('checked', false).val(0);
                    $('.checkbox-group-1 input[type="checkbox"], .checkbox-group-2 input[type="checkbox"], .checkbox-group-3 input[type="checkbox"]').prop('checked', false).val(0);

                    // Calcular impuestos cuando perfil es 4
                    calcularImpuestos();
                } else {
                    $('.checkbox-group-1, .checkbox-group-2, .checkbox-group-3, .checkbox-group-4').hide();
                    $('.checkbox-group-1 input[type="checkbox"], .checkbox-group-2 input[type="checkbox"], .checkbox-group-3 input[type="checkbox"], .checkbox-group-4 input[type="checkbox"]').prop('checked', false).val(0);
                }

                // Calcular y mostrar el valor del IVA inmobiliaria solo para perfil 2 y 4
                calcularComision();
            });

            // Escuchar cambios en el campo comision1
            $('select[name="comision1"]').change(function() {
                var comision1 = $(this).val();

                if (comision1 == 0) {
                    $('#comision2').prop('disabled', false).val('');
                } else {
                    $('#comision2').prop('disabled', true).val('');
                }

                if (comision1 == 1) {
                    $('#acuerdo').prop('disabled', false).val('');
                } else {
                    $('#acuerdo').prop('disabled', true).val('');
                }

                calcularComision();
            });

            // Asegurar que los checkboxes tengan valor 0 o 1
            $('.checkbox-group input[type="checkbox"]').change(function() {
                if ($(this).is(':checked')) {
                    $(this).val(1);
                } else {
                    $(this).val(0);
                }

                if ($(this).attr('name') === 'cbox17') {
                    calcularImpuestos();
                }
            });

            // Calcular y mostrar el valor de la comisión en formato COP
            function calcularComision() {
                var rentaCon = parseFloat($('#renta_con').val());
                var comision1 = parseFloat($('select[name="comision1"]').val());
                var comision2 = parseFloat($('#comision2').val());
                var acuerdo = parseFloat($('#acuerdo').val());
                var comisionPago = 0;

                if ($('select[name="comision1"]').val() == 1 && !isNaN(acuerdo)) {
                    comisionPago = acuerdo;
                } else if (!isNaN(comision2) && comision1 == 0) {
                    comisionPago = rentaCon * (comision2 / 100);
                } else if (!isNaN(comision1)) {
                    comisionPago = rentaCon * (comision1 / 100);
                }

                $('#comision_pago').val('$' + comisionPago.toLocaleString('es-CO', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));

                // Calcular y mostrar el valor del IVA inmobiliaria solo para perfil 2 y 4
                var perfil = $('select[name="perfil"]').val();
                if (perfil == 2 || perfil == 4) {
                    var ivaInmo = comisionPago * 0.19;
                    $('#iva_inmo').val('$' + ivaInmo.toLocaleString('es-CO', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
                } else {
                    $('#iva_inmo').val('');
                }
            }

            // Calcular y mostrar el valor de los impuestos en formato COP
            function calcularImpuestos() {
                var canonCon = parseFloat($('#canon_con').val());
                var rteFte1 = parseFloat($('#rte_fte1').val());
                var rteIca1 = parseFloat($('#rte_ica1').val());

                if (!isNaN(rteFte1)) {
                    var rteFte2 = canonCon * (rteFte1 / 100);
                    $('#rte_fte2').val('$' + rteFte2.toLocaleString('es-CO', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
                }

                if (!isNaN(rteIca1)) {
                    var rteIca2 = canonCon * rteIca1 / 1000;
                    $('#rte_ica2').val('$' + rteIca2.toLocaleString('es-CO', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
                }

                var ivaCon = parseFloat($('#iva_con').val());
                var perfil = $('select[name="perfil"]').val();
                var cbox17 = $('input[name="cbox17"]').val();

                if ((perfil == 2 || perfil == 4) && cbox17 == 1) {
                    $('#rte_iva1').val('$' + (ivaCon * 0.15).toLocaleString('es-CO', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
                } else {
                    $('#rte_iva1').val('');
                }
            }

            // Escuchar cambios en los campos relacionados con la comisión
            $('select[name="comision1"], #comision2, #acuerdo, #renta_con').change(function() {
                calcularComision();
            });

            // Escuchar cambios en los campos relacionados con los impuestos
            $('#canon_con, #rte_fte1, #rte_ica1').change(function() {
                calcularImpuestos();
            });

            // Calcular la comisión e impuestos al cargar la página
            calcularComision();
            calcularImpuestos();
        });
    </script>

</head>
<body>
    <?php
        include("../../conexion.php");
        $num_con  = $_GET['num_con'];
        if(isset($_GET['num_con']))
        {
           $sql = mysqli_query($mysqli, "SELECT * FROM contratos WHERE num_con = '$num_con'");
           $row = mysqli_fetch_array($sql);
        }
    ?>

    <div class="container">
        
        <h1><img src='../../img/logo.png' width="80" height="56" class="responsive"><b><i class="fa-solid fa-money-check-dollar"></i> GENERAR PAGOS INMUEBLE</b></h1>
        <p><i><b><font size=3 color=#c68615>*Datos obligatorios</i></b></font></p>

        <form action='makepay1.php?num_con=<?php echo $row['num_con']; ?>' enctype="multipart/form-data" method="POST">
    <div class="form-group">
        <div class="row">
            <div class="col-12 col-sm-2">
                <label for="num_con">CONTRATO No.</label>
                <input type='number' name='num_con' class='form-control' id="num_con" value='<?php echo $row['num_con']; ?>' readonly />
            </div>
            <div class="col-12 col-sm-2">
                <label for="fec_inicio_con">FECHA INICIO:</label>
                <input type='date' name='fec_inicio_con' class='form-control' id="fec_inicio_con" value='<?php echo $row['fec_inicio_con']; ?>' readonly />
            </div>
            <div class="col-12 col-sm-2">
                <label for="vigencia_duracion_con">VIGENCIA:</label>
                <input type='number' name='vigencia_duracion_con' class='form-control' id="vigencia_duracion_con" value='<?php echo $row['vigencia_duracion_con']; ?>' readonly />
            </div>
            <div class="col-12 col-sm-3">
                <label for="pago_propietario">* PAGO A PROPIETARIO:</label>
                <select class="form-control" name="pago_propietario" required>
                    <option value=""></option>
                    <option value="TRANSFERENCIA">TRANSFERENCIA</option>
                    <option value="EFECTIVO">EFECTIVO</option>
                </select>
            </div>
            <div class="col-12 col-sm-3">
                <label for="transferencia_propietario">* TRANSFERENCIA:</label>
                <select class="form-control" name="transferencia_propietario" required>
                    <option value=""></option>
                    <option value="Banco Agrario de Colombia">Banco Agrario de Colombia</option>
                    <option value="Banco AV Villas">Banco AV Villas</option>
                    <option value="Banco BBVA">Banco BBVA</option>
                    <option value="Banco BCSC">Banco BCSC</option>
                    <option value="Banco Citibank">Banco Citibank</option>
                    <option value="Banco Coopcentral">Banco Coopcentral</option>
                    <option value="Banco Davivienda">Banco Davivienda</option>
                    <option value="Banco de Bogotá">Banco de Bogotá</option>
                    <option value="Banco de Occidente">Banco de Occidente</option>
                    <option value="Banco Falabella">Banco Falabella</option>
                    <option value="Banco Finandina">Banco Finandina</option>
                    <option value="Banco GNB Sudameris">Banco GNB Sudameris</option>
                    <option value="Banco Itaú Corpbanca Colombia S.A.">Banco Itaú Corpbanca Colombia S.A.</option>
                    <option value="Banco Pichincha">Banco Pichincha</option>
                    <option value="Banco Popular">Banco Popular</option>
                    <option value="Bancolombia">Bancolombia</option>
                    <option value="Bancoomeva">Bancoomeva</option>
                    <option value="Nequi">Nequi</option>
                    <option value="Daviplata">Daviplata</option>
                    <option value="Transfiya">Transfiya</option>
                    <option value="N/A">N/A</option>
                </select>
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="row">
            <div class="col-12 col-sm-2">
                <label for="factura_electronica0">* FACT. ELECT.</label>
                <select class="form-control" name="factura_electronica0" required>
                    <option value=""></option>
                    <option value="SI">SI</option>
                    <option value="NO">NO</option>
                </select>
            </div>
            <div class="col-12 col-sm-2">
                <label for="factura_electronica1">FACT. VIDECO:</label>
                <select class="form-control" name="factura_electronica1">
                    <option value=""></option>
                    <option value="Factura Electrónica">Factura Electrónica</option>
                    <option value="Orden de Pago">Orden de Pago</option>
                    <option value="NO">NO</option>                    
                    <option value="N/A">N/A</option>
                </select>
            </div>
            <div class="col-12 col-sm-2">
                <label for="factura_electronica2">FACT. PROPIETARIO:</label>
                <select class="form-control" name="factura_electronica2">
                    <option value=""></option>
                    <option value="Factura Propietario">Factura Propietario</option>
                    <option value="N/A">N/A</option>
                </select>
            </div>
            <div class="col-12 col-sm-2">
                <strong><label for="canon_con">CANON $</label></strong>
                <input type='number' name='canon_con' id="canon_con" class='form-control' value='<?php echo $row['canon_con']; ?>' readonly style="font-weight:bold;" />
            </div>
            <div class="col-12 col-sm-2">
                <strong><label for="iva_con">IVA $</label></strong>
                <input type='number' name='iva_con' id="iva_con" class='form-control' value='<?php echo $row['iva_con']; ?>' readonly style="font-weight:bold;" />
            </div>
            <div class="col-12 col-sm-2">
                <strong><label for="admon_con">ADMINISTRACION $</label></strong>
                <input type='number' name='admon_con' id="admon_con" class='form-control' value='<?php echo $row['admon_con']; ?>' readonly style="font-weight:bold;" />
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="row">
            <div class="col-12 col-sm-2">
                <strong><label for="renta_con">RENTA $</label></strong>
                <input type='number' name='renta_con' id="renta_con" class='form-control' value='<?php echo $row['renta_con']; ?>' readonly style="font-weight:bold;" />
            </div>
            <div class="col-12 col-sm-4">
                <label for="perfil">* PERFIL:</label>
                <select class="form-control" name="perfil" required>
                    <option value=""></option>
                    <option value=1>1. Personas naturales régimen ordinario de tributación</option>
                    <option value=2>2. Personas jurídicas régimen ordinario de tributación</option>
                    <option value=3>3. Personas naturales régimen simple de tributación</option>
                    <option value=4>4. Personas jurídicas régimen simple de tributación</option>
                </select>
            </div>
            <div class="col-12 col-sm-2">
                <label for="comision1">* COMISION:</label>
                <select class="form-control" name="comision1" required>
                    <option value=""></option>
                    <option value=8>8%</option>
                    <option value=10>10%</option>
                    <option value=12>12%</option>
                    <option value=0>OTRO</option>
                    <option value=1>ACUERDO</option>
                </select>
            </div>
            <div class="col-12 col-sm-2">
                <label for="comision2">% COMISION:</label>
                <input type='number' min='8.0' max='12.0' step='0.1' name='comision2' id='comision2' class='form-control'/>
            </div>
            <div class="col-12 col-sm-2">
                <label for="acuerdo">ACUERDO $</label>
                <input type='number' name='acuerdo' id='acuerdo' class='form-control'/>
            </div>
        </div>
    </div>

    <hr style="border: 1px solid #F3840D; border-radius: 5px;">
    <h4><strong>Impuestos Propietario:</strong></h4>
    <div class="form-group">
        <div class="row">
            <div class="col-12 col-sm-2">
                <label for="rte_fte1">RTE FTE %</label>
                <select class="form-control" name="rte_fte1" id="rte_fte1">
                    <option value=""></option>
                    <option value=3.5>3.5%</option>
                    <option value=20>20%</option>
                </select>
            </div>
            <div class="col-12 col-sm-2">
                <strong><label for="rte_fte2">RTE FTE $</label></strong>
                <input type='text' name='rte_fte2' id="rte_fte2" class='form-control' readonly style="font-weight:bold;" />
            </div>
            <div class="col-12 col-sm-2">
                <label for="rte_ica1">RTE ICA</label>
                <select class="form-control" name="rte_ica1" id="rte_ica1">
                    <option value=""></option>
                    <option value=7>7</option>
                    <option value=8>8</option>
                    <option value=9>9</option>
                    <option value=10>10</option>
                    <option value=0>N/A</option>
                </select>
            </div>
            <div class="col-12 col-sm-2">
                <strong><label for="rte_ica2">RTE ICA $</label></strong>
                <input type='text' name='rte_ica2' id="rte_ica2" class='form-control' readonly style="font-weight:bold;" />
            </div>
            <div class="col-12 col-sm-2">
                <strong><label for="rte_iva1">RTE IVA $</label></strong>
                <input type='text' name='rte_iva1' id="rte_iva1" class='form-control' readonly style="font-weight:bold;" />
            </div>
        </div>
    </div>

    <h4><strong>Impuestos Inmobiliaria:</strong></h4>
    <div class="form-group">
        <div class="row">
            <div class="col-12 col-sm-2">
                <strong><label for="comision_pago">COMISIÓN</label>
                <input type='text' name='comision_pago' id="comision_pago" class='form-control comision-pago' readonly/></strong>
            </div>
            <div class="col-12 col-sm-2">
                <label for="iva_inmo">IVA $</label>
                <input type='text' name='iva_inmo' id="iva_inmo" class='form-control' readonly style="font-weight:bold;" />
            </div>
            <div class="col-12 col-sm-2">
                <label for="rte_fte3">RTE FTE %</label>
                <select class="form-control" name="rte_fte3" id="rte_fte3">
                    <option value=""></option>
                    <option value=10>10%</option>
                    <option value=11>11%</option>
                </select>
            </div>
            <div class="col-12 col-sm-2">
                <strong><label for="rte_fte4">RTE FTE $</label></strong>
                <input type='text' name='rte_fte4' id="rte_fte4" class='form-control' readonly style="font-weight:bold;" />
            </div>
            <div class="col-12 col-sm-2">
                <strong><label for="rte_ica3">RTE ICA $</label></strong>
                <input type='number' name='rte_ica3' id="rte_ica3" class='form-control' value='<?php echo $row['rte_ica3']; ?>' readonly style="font-weight:bold;" />
            </div>
            <div class="col-12 col-sm-2">
                <strong><label for="rte_iva2">RTE IVA $</label></strong>
                <input type='number' name='rte_iva2' id="rte_iva2" class='form-control' value='<?php echo $row['rte_iva2']; ?>' readonly style="font-weight:bold;" />
            </div>
        </div>
    </div>

    <hr style="border: 1px solid #919198; border-radius: 5px;">
    <div class="form-group">
        <div class="row">
            <div class="col-12 col-sm-2">
                <strong><label for="prorrateo">* ¿PRORRATEO?</label></strong>
                <select class="form-control" name="prorrateo" required>
                    <option value=""></option>
                    <option value=1>SI</option>
                    <option value=0>NO</option>
                </select>
            </div>
            <div class="col-12 col-sm-2">
                <label for="dias_prorra">DÍAS PRORRATEO</label></strong>
                <input type='number' name='dias_prorra' min=1 id="dias_prorra" class='form-control' value='<?php echo $row['dias_prorra']; ?>' />
            </div>
            <div class="col-12 col-sm-3">
                <label for="valor_prorra">VALOR 1º PRORRATEO $</label></strong>
                <input type='number' name='valor_prorra' min=1 id="valor_prorra" class='form-control' value='<?php echo $row['valor_prorra']; ?>' />
            </div>
        </div>
    </div>
    <hr style="border: 1px solid #919198; border-radius: 5px;">

    <hr style="border: 4px solid #24E924; border-radius: 5px;">
    <div class="form-group checkbox-group-1">
        <div class="row">
            <div class="col-12">
                <label for="containerCheck"><strong>Personas naturales régimen ordinario de tributación:</strong></label><br>
                <input type="checkbox" name="cbox1" value=1 /> PN - Personal natural y asimiladas<br>
                <input type="checkbox" name="cbox2" value=1 /> TO - Régimen ordinario de tributación<br>
                <input type="checkbox" name="cbox3" value=1 /> RS - No responsable impuesto a las ventas<br>
            </div>
        </div>
    </div>

    <div class="form-group checkbox-group-2">
        <div class="row">
            <div class="col-12">
                <label for="containerCheck"><strong>Personas jurídicas régimen ordinario de tributación:</strong></label><br>
                <input type="checkbox" name="cbox4" value=1 /> PJ - Personal jurídica y asimiladas<br>
                <input type="checkbox" name="cbox5" value=1 /> TO - Régimen ordinario de tributación<br>
                <input type="checkbox" name="cbox6" value=1 /> RC - Responsable de impuesto a las ventas<br>
                <input type="checkbox" name="cbox7" value=1 /> AG - Agente retenedor (puede practicar retención)<br>
                <input type="checkbox" name="cbox8" value=1 /> RI - Responsable Rete-ICA<br>
                <input type="checkbox" name="cbox17" value=1 /> GC - Gran Contribuyente<br> <!--Campo nuevo-->
            </div>
        </div>
    </div>

    <div class="form-group checkbox-group-3">
        <div class="row">
            <div class="col-12">
                <label for="containerCheck"><strong>Personas naturales régimen simple de tributación:</strong></label><br>
                <input type="checkbox" name="cbox9" value=1 /> PN - Personal natural y asimiladas<br>
                <input type="checkbox" name="cbox10" value=1 /> TS - Régimen simple de tributación (0 - 47)<br>
                <input type="checkbox" name="cbox11" value=1 /> RC - Responsable impuesto a las ventas<br>
                <input type="checkbox" name="cbox12" value=0 /> AG - Agente retenedor (puede practicar retención)<br>
            </div>
        </div>
    </div>

    <div class="form-group checkbox-group-4">
        <div class="row">
            <div class="col-12">
                <label for="containerCheck"><strong>Personas jurídicas régimen simple de tributación:</strong></label><br>
                <input type="checkbox" name="cbox13" value=1 /> PJ - Personal jurídica y asimiladas<br>
                <input type="checkbox" name="cbox14" value=1 /> TS - Régimen simple de tributación (0 - 47)<br>
                <input type="checkbox" name="cbox15" value=1 /> RC - Responsable de impuesto a las ventas<br>
                <input type="checkbox" name="cbox16" value=0 /> AG - Agente retenedor (puede practicar retención)<br>
            </div>
        </div>
    </div>
    <hr style="border: 4px solid #24E924; border-radius: 5px;">

    <button type="submit" class="btn btn-primary" name="btn-update">
        <span class="spinner-border spinner-border-sm"></span>
        GENERAR PAGOS INMUEBLE
    </button>
    <button type="reset" class="btn btn-outline-dark" role='link' onclick="history.back();" type='reset'><img src='../../img/atras.png' width=27 height=27> REGRESAR
    </button>
</form>
    </div>
</body>
</html>
